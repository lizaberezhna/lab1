import os
import re
import string
import numpy as np
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score  # Додано

# Завантаження необхідних даних NLTK
nltk.download('punkt')  # Завантаження моделі токенізації
nltk.download('stopwords')  # Завантаження списку стоп-слів
nltk.download('punkt_tab')  # Додатковий ресурс для токенізації

# Підготовка даних
def load_data(path):
    data = []
    labels = []
    for label, folder in enumerate(['neg', 'pos']):
        folder_path = os.path.join(path, folder)
        for file_name in os.listdir(folder_path):
            with open(os.path.join(folder_path, file_name), 'r', encoding='utf-8') as file:
                data.append(file.read())
                labels.append(label)
    return data, np.array(labels)

# Попередня обробка тексту
def preprocess_text(text):
    stemmer = PorterStemmer()
    stop_words = set(stopwords.words('english'))
    text = re.sub(r'\d+', '', text)  # Видалення цифр
    text = text.lower()  # Перетворення на нижній регістр
    text = text.translate(str.maketrans('', '', string.punctuation))  # Видалення пунктуації
    words = word_tokenize(text)  # Токенізація
    words = [stemmer.stem(word) for word in words if word not in stop_words]  # Видалення стоп-слів і стемінг
    return words

# Побудова частотного словника
def build_freq_dict(data, labels):
    freqs = {}
    for text, label in zip(data, labels):
        words = preprocess_text(text)
        for word in words:
            pair = (word, label)
            freqs[pair] = freqs.get(pair, 0) + 1
    return freqs

# Витяг ознак
def extract_features(text, freqs):
    words = preprocess_text(text)
    x = np.zeros((3,))
    x[0] = 1  # Bias
    for word in words:
        x[1] += freqs.get((word, 1), 0)  # Позитивні
        x[2] += freqs.get((word, 0), 0)  # Негативні
    return x

# Сигмоїдна функція
def sigmoid(z):
    # Обмежуємо значення, щоб уникнути переповнення
    z = np.clip(z, -500, 500)
    return 1 / (1 + np.exp(-z))


# Градієнтний спуск
def gradient_descent(X, y, theta, alpha, num_iters):
    m = len(y)
    for _ in range(num_iters):
        z = np.dot(X, theta)
        h = sigmoid(z)
        epsilon = 1e-15  # Маленьке значення, яке додається для уникнення нуля
        h = np.clip(h, epsilon, 1 - epsilon)
        loss = (-1 / m) * (np.dot(y.T, np.log(h)) + np.dot((1 - y).T, np.log(1 - h)))

        gradient = np.dot(X.T, (h - y)) / m
        theta -= alpha * gradient
    return loss, theta

# Передбачення
def predict(text, freqs, theta):
    x = extract_features(text, freqs)
    y_pred = sigmoid(np.dot(x, theta))
    return 1 if y_pred > 0.5 else 0

# Основна частина
if __name__ == "__main__":
    # Завантаження даних
    data_path = r"C:\Users\Liza\PycharmProjects\pythonProject\movie_reviews"
    data, labels = load_data(data_path)

    # Розділення даних на тренувальну і тестову вибірки
    train_data, test_data, train_labels, test_labels = train_test_split(data, labels, test_size=0.2, random_state=42)

    # Побудова словника частотності
    freqs = build_freq_dict(train_data, train_labels)

    # Формування матриці ознак
    X_train = np.array([extract_features(text, freqs) for text in train_data])
    X_test = np.array([extract_features(text, freqs) for text in test_data])

    y_train = train_labels.reshape(-1, 1)
    y_test = test_labels.reshape(-1, 1)

    # Навчання моделі
    theta = np.zeros((3, 1))
    alpha = 0.01
    num_iters = 1000
    loss, theta = gradient_descent(X_train, y_train, theta, alpha, num_iters)

    # Оцінка моделі
    y_pred = [predict(text, freqs, theta) for text in test_data]
    accuracy = accuracy_score(y_test.flatten(), y_pred)  # Використовуємо flatten() для відповідності розмірів
    print(f"Точність моделі: {accuracy:.4f}")

    # Тестування моделі на власних прикладах
    my_text = "This movie was fantastic! I loved it."
    prediction = predict(my_text, freqs, theta)
    print(f"Тональність тексту: {'Позитивна' if prediction == 1 else 'Негативна'}")
